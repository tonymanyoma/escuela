import Vue from 'vue';
export default Vue.observable({ editMessage: null });